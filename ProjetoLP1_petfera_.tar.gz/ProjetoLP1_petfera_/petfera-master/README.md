para compilar:

make
./bin/petfera
