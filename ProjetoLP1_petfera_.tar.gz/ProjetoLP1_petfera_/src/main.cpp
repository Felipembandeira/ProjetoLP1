#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <memory>
#include <vector>
#include "funcionario.h"
#include "animal.h"
//#include "animalsilvestre.h"

using namespace std;


int main() {

    map<int, Funcionario*> funcionarios;
    map<int, Animal*> animais;
   
	ifstream funcionarios_arq;
	ifstream animais_arq;

	funcionarios_arq.open("data/funcionarios.csv");
	animais_arq.open("data/animais.csv");


	if(!funcionarios_arq || !animais_arq) {
		cerr << "O arquivo não foi encontrado" << endl;
		cerr << "O programa será encerrado" << endl;
		exit(1);
	}


string linha;
for (int i = 0; i < 10; i++) {


	getline(funcionarios_arq, linha);
                

	stringstream aux(linha);
    string id, funcao, nome, cpf, idade, tipo_sang, fator_rh, especialidade;
        
        getline(aux, id, ';');
        getline(aux, funcao, ';');
        getline(aux, nome, ';');
        getline(aux, cpf, ';');
        getline(aux, idade,';');
        getline(aux, tipo_sang, ';');
        getline(aux, fator_rh, ';');
        getline(aux, especialidade, ';');           
		

		Funcionario *func = new Funcionario;

		func->setId(stoi (id));
		func->setTipoFunc(funcao);
		func->setNome(nome);
		func->setCpf(cpf);
		func->setIdade(stoi (idade));
		func->setTipo_Sanguineo(tipo_sang);
		func->setFatorRH(fator_rh);
		func->setEspecialidade(especialidade); 

		funcionarios.insert(pair<int, Funcionario*>(func->getId(), func));

}

   
string linha2;
for (int j = 0; j < 4; j++) {


	getline(animais_arq, linha2);
                

	stringstream aux(linha2);
    string id, classe, nome, cientifico, sexo, tamanho, dieta, batismo;
        
        getline(aux, id, ';');
        getline(aux, classe, ';');
        getline(aux, nome, ';');
        getline(aux, cientifico, ';');
        getline(aux, sexo,';');
        getline(aux, tamanho, ';');
        getline(aux, dieta, ';');
        getline(aux, batismo, ';');           
		

		Animal *ani = new Animal;

		ani->setId(stoi (id));
		ani->setClasse(classe);
		ani->setNome(nome);
		ani->setCientifico(cientifico);
		ani->setSexo(sexo);
		ani->setTamanho(stof (tamanho));
		ani->setDieta(dieta);
		//ani->setDieta(dieta);
		//ani->setDieta(dieta);
		ani->setBatismo(batismo); 


		//void setVeterinario(Veterinario *v);
	
		//void setTratador(Tratador *t);
		

		animais.insert(pair<int, Animal*>(ani->getId(), ani));

}




 funcionarios_arq.close();
 animais_arq.close();






cout << "<<PET FERA>>" << endl;

while(1) {

 		string op1;
 		int escolha;
 		int op2;

		
		cout <<	"	Digite 1 para consultar funcionario especifico cadastrado" << endl;
		cout <<	"	Digite 2 para consultar lista de funcionarios cadastrados" << endl;
		cout <<	"	Digite 3 para remover funcionario especifico cadastrado" << endl;

		cout << "	Digite 4 para consultar animal específico cadastrado" << endl;
		cout << "	Digite 5 para consultar lista de animais cadastrados" << endl;
		cout << "	Digite 6 para remover animal especifico cadastrado " << endl;

		cout << "	Digite 7 para sair do PetFera" << endl;

		cout << "Digite sua opção:\n";
		cin >> escolha;


 		//Funcionários
 		switch(escolha){


 			case 1:
 			
 				ConsultarFuncionario(funcionarios);

 				break;

 			case 2:
 			
 				ListarFuncionarios (funcionarios);

 				break;

 			case 3:	
 			
 				RemoverFuncionario(funcionarios);

 				break;
 		 	
 		 	case 4:
 			
 				ConsultarAnimal(animais);

 				break;

 			case 5:
 			
 				ListarAnimais (animais);

 				break;

 			case 6:	
 			
 				RemoverAnimal(animais);

 				break;

 			case 7:
 			 	return EXIT_SUCCESS;	
 		}
				


}

return 0;
	}

