#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <memory>
#include "animal.h"

using namespace std;


Animal::Animal() {}
Animal::~Animal() {}

int Animal::getId() {
	return id;
}

void Animal::setId(int a) {
	id = a;
}

string Animal::getClasse() {
	return classe;
}

void Animal::setClasse(string c) {
	classe = c;
}

string Animal::getNome() {
	return nome;
}

void Animal::setNome(string n) {
	nome = n;
}

string Animal::getCientifico() {
	return cientifico;
}

void Animal::setCientifico(string c) {
	cientifico = c;
}

string Animal::getSexo() {
	return sexo;
}

void Animal::setSexo(string s) {
	sexo = s;
}

float Animal::getTamanho() {
	return tamanho;
}
		
void Animal::setTamanho(float t) {
	tamanho = t;
}

string Animal::getDieta() {
	return dieta;
}

void Animal::setDieta(string d) {
	dieta = d;
}

Veterinario* Animal::getVeterinario() {
	return veterinario;
}

void Animal::setVeterinario(Veterinario *v) {
	veterinario = v;
}

Tratador* Animal::getTratador() {
	return tratador;
}

void Animal::setTratador(Tratador *t) {
	tratador = t;
}

string Animal::getBatismo() {
	return batismo;
}

void Animal::setBatismo(string b) {
	batismo = b;
}

/*
istream& operator>> (istream &is, Animal &animals) {

	string saida;
	getline(is, saida);
	istringstream iss(saida);

	iss >> animals.id;						
	iss.ignore();						
	getline(iss, animals.classe, ';'); 		
	getline(iss, animals.nome, ';');			
    getline(iss, animals.cientifico, ';');	
    iss >> animals.sexo;						
    iss.ignore();						
    iss >> animals.tamanho;					
    iss.ignore();						
    getline(iss, animals.dieta, ';');
    
	getline(iss, animals.batismo, ';');

    if (animals.classe == "Amphibia") {
    	Anfibio anfibio_copy;
    	iss >> anfibio_copy.total_mudas;
    	iss.ignore();
    	getline(iss, anfibio_copy.ultima_muda, ';');
    } 	
    else if (animals.classe == "Mammalia") {
    	Mamifero mamifero_copy;
    	getline(iss, mamifero_copy.cor_pelo,';');
    }
    else if (animals.classe == "Reptilia"){
    	Reptil reptil_copy;
        iss >> reptil_copy.venenoso;
    	iss.ignore();
    	getline(iss, reptil_copy.tipo_veneno,';');
    }
    else {
    	Ave bird;
    	iss >> bird.tamanho_bico;
    	iss.ignore();
    	iss >> bird.envergadura;
    	iss.ignore();
    }

    return is;
}



ostream& operator<< (ostream &os, Animal &animals) {

	os << "Identificador do animal: " << animals.id << endl;
	os << "Classe do animal: " << animals.classe << endl;	
	os << "Nome do animal: " << animals.nome << endl;
	os << "Nome científico do animal: " << animals.cientifico << endl;
	os << "Sexo do animal: " << animals.sexo << endl;
	os << "Tamanho médio em metros: " << animals.tamanho << endl;
	os << "Dieta predominante: " << animals.dieta << endl;
	os << "Nome de batismo: " << animals.batismo << endl;
	os << endl;

   

	return os;
}

*/

Anfibio::Anfibio() {
	total_mudas = 0;
	ultima_muda = "";
}


Anfibio::~Anfibio() {

}

int Anfibio::getTotalMudas() {
	return total_mudas;
}

void Anfibio::setTotalMUdas(int tm) {
	total_mudas = tm;
}

string Anfibio::getUltimaMuda() {
	return ultima_muda;
}

void Anfibio::setUltimaMuda(string um) {
	ultima_muda = um;
}


Mamifero::Mamifero() {
	cor_pelo = "";
}


Mamifero::~Mamifero() {

}

string Mamifero::getCorPelo() {
	return cor_pelo;
}

void Mamifero::setCorPelo(string cp) {
	cor_pelo = cp;
}	


Reptil::Reptil() {
	venenoso = false;
	tipo_veneno = "";
}


Reptil::~Reptil() {

}

bool Reptil::getVenenoso() {
	return venenoso;
}


void Reptil::setVenenoso(bool v) {
	venenoso = v;
}

string Reptil::getTipoVeneno() {
	return tipo_veneno;
}

void Reptil::setTipoVeneno(string tv) {
	tipo_veneno = tv;
}


Ave::Ave() {
	tamanho_bico = 0;
	envergadura = 0;
}


Ave::~Ave() {

}

int Ave::getTamanhoBico() {
	return tamanho_bico;
}

void Ave::setTamanhoBico(int tb) {
	tamanho_bico = tb;
}

int Ave::getEnvergadura() {
	return envergadura;
}

void Ave::setEnvergadura(int e) {
	envergadura = e;
}




void RemoverAnimal(map<int, Animal*> &animais) {

	int id;

	cout << "Defina qual o id do animal que se busca: ";
	cin >> id;

    map<int, Animal*>::iterator itM_ =  animais.find(id);

	    if(itM_ != animais.end())
	    {
	        animais.erase(itM_);
	        cout << "Funcionário foi removido com sucesso" << endl;
	    }
	    else
	    {
	        cout << "Funcionario não encontrado" << endl;
	    }

}



void ConsultarAnimal(map<int, Animal*> &animais) {

	int id;

	cout << "Defina qual o id do animal que se busca: ";
	cin >> id;

	map<int, Animal*>::iterator itM =  animais.find(id);

	if (itM != animais.end()){


		cout << "Identificador do animal: " << (itM->second)->getId() << endl;
		cout << "Classe do animal:" << (itM->second)->getClasse() << endl;
		cout << "Nome do animal:" << (itM->second)->getNome() << endl;
		cout << "Nome científico do animal:" << (itM->second)->getCientifico() << endl;
		cout << "Sexo do animal: " << (itM->second)->getSexo()<< endl;
		cout << "Tamanho médio em metros:  " << (itM->second)->getTamanho() << endl;
		cout << "Dieta predominante: " << (itM->second)->getDieta() << endl;
		cout << "Nome de batismo: " << (itM->second)->getBatismo() << endl;
		cout << endl;





	}
}


void ListarAnimais (map<int, Animal*> &animais) {

	for(auto itM  = animais.begin(); itM != animais.end(); itM++){

		cout << "Identificador do animal: " << (itM->second)->getId() << endl;
		cout << "Classe do animal:" << (itM->second)->getClasse() << endl;
		cout << "Nome do animal:" << (itM->second)->getNome() << endl;
		cout << "Nome científico do animal:" << (itM->second)->getCientifico() << endl;
		cout << "Sexo do animal: " << (itM->second)->getSexo()<< endl;
		cout << "Tamanho médio em metros:  " << (itM->second)->getTamanho() << endl;
		cout << "Dieta predominante: " << (itM->second)->getDieta() << endl;
		cout << "Nome de batismo: " << (itM->second)->getBatismo() << endl;
		cout << endl;
	}

}