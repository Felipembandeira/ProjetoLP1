#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <memory>
#include "funcionario.h"


using namespace std;

Funcionario::Funcionario() {}
Funcionario::~Funcionario() {}

int Funcionario::getId() {
	return id;
}

void Funcionario::setId(int i) {
	id = i;
}


string Funcionario::getTipoFunc() {
	return tipofunc;
}

void Funcionario::setTipoFunc(string t) {
	tipofunc = t;
}


string Funcionario::getNome() {
	return nome;
}

void Funcionario::setNome(string n) {
	nome = n;
}

string Funcionario::getCpf() {
	return cpf;
}

void Funcionario::setCpf(string c) {
	cpf = c;
}

int Funcionario::getIdade() {
	return idade;
}

void Funcionario::setIdade(int i) {
	idade = i;
}

string Funcionario::getTipo_Sanguineo() {
	return tipo_sanguineo;
}

void Funcionario::setTipo_Sanguineo(string ts) {
	tipo_sanguineo = ts;
}

string Funcionario::getFatorRH() {
	return fatorRH;
}

void Funcionario::setFatorRH(string rh) {
	fatorRH = rh;
}

string Funcionario::getEspecialidade() {
	return especialidade;
}

void Funcionario::setEspecialidade(string e) {
	especialidade = e;
}






Veterinario::Veterinario() {}
Veterinario::~Veterinario() {}

void Veterinario::setcrmv(string c) {
	crmv = c;
}
string Veterinario::getcrmv() {
	return crmv;
}


Tratador::Tratador() {}
Tratador::~Tratador() {}

void Tratador::setNivelseguranca(int n) {
	nivel_seguranca = n;
}
int Tratador::getNivelseguranca() {
	return nivel_seguranca;
}

	


void RemoverFuncionario(map<int, Funcionario*> &funcionarios) {

	int id;

	cout << "Defina qual o id do funcionário que se busca: ";
	cin >> id;

    map<int, Funcionario*>::iterator itM_ =  funcionarios.find(id);

	    if(itM_ != funcionarios.end())
	    {
	        funcionarios.erase(itM_);
	        cout << "Funcionário foi removido com sucesso" << endl;
	    }
	    else
	    {
	        cout << "Funcionario não encontrado" << endl;
	    }

}



void ConsultarFuncionario(map<int, Funcionario*> &funcionarios) {

	int id;

	cout << "Defina qual o id do funcionário que se busca: ";
	cin >> id;

	map<int, Funcionario*>::iterator itM = funcionarios.find(id);

	if (itM != funcionarios.end()){


		cout << "Identificador do funcionário: " << (itM->second)->getId() << endl;
		cout << "Função: " << (itM->second)->getTipoFunc() << endl;
		cout << "Nome do funcionário: " << (itM->second)->getNome() << endl;
		cout << "CPF do funcionário: " << (itM->second)->getCpf() << endl;
		cout << "Idade do funcionário: " << (itM->second)->getIdade()<< endl;
		cout << "Tipo Sanguíneo: " << (itM->second)->getTipo_Sanguineo() << endl;
		cout << "Fator RH: " << (itM->second)->getFatorRH() << endl;
		cout << "Especialidade: " << (itM->second)->getEspecialidade() << endl;
		cout << endl;
	}
}


void ListarFuncionarios (map<int, Funcionario*> &funcionarios) {



	for(auto itM__  = funcionarios.begin(); itM__ != funcionarios.end(); itM__++){

		cout << "Identificador do funcionário: " << (itM__->second)->getId() << endl;
		cout << "Função: " << (itM__->second)->getTipoFunc() << endl;
		cout << "Nome do funcionário: " << (itM__->second)->getNome() << endl;
		cout << "CPF do funcionário: " << (itM__->second)->getCpf() << endl;
		cout << "Idade do funcionário: " << (itM__->second)->getIdade()<< endl;
		cout << "Tipo Sanguíneo: " << (itM__->second)->getTipo_Sanguineo() << endl;
		cout << "Fator RH: " << (itM__->second)->getFatorRH() << endl;
		cout << "Especialidade: " << (itM__->second)->getEspecialidade() << endl;
		cout << endl;
	}

}	








/*
istream& operator>> (istream &is, Funcionario &func) {
	string linha,escolha_funcionario;
	int i;
	getline(is, linha);
	istringstream iss(linha);

	iss >> i;	
	iss.ignore();
	getline(iss, escolha_funcionario, ';');

	func.id = i;
	func.tipofunc = escolha_funcionario;
	getline(iss, func.nome, ';');			
    getline(iss, func.cpf, ';');	
    iss >> func.idade;						
    iss.ignore();
    getline(iss, func.tipo_sanguineo, ';');					
    iss >> func.fatorRH;		
	iss.ignore();					
    getline(iss, func.especialidade, ';');  


	

 cout << "entrou no isssssssssssssss" << endl;

 return is;
}
*/


 /*

	string id, idade;

	getline(is, id, ';');
		func.id = stoi (id);
	getline(is, func.tipofunc, ';');
	getline(is, func.nome, ';');	
	getline(is, func.cpf, ';');	
	getline(is, idade, ';');	
		func.idade = stoi (idade);
	getline(is, func.tipo_sanguineo, ';');	
	getline(is, func.fatorRH, ';');	
	getline(is, func.especialidade, ';');	

*/


/*


	string linha,escolha_funcionario;
	int i;
	getline(is, linha);
	istringstream iss(linha);

	iss >> i;	
	iss.ignore();
	getline(iss, escolha_funcionario, ';');

	func.id = i;
	func.tipofunc = escolha_funcionario;
	getline(iss, func.nome, ';');			
    getline(iss, func.cpf, ';');	
    iss >> func.idade;						
    iss.ignore();						
    getline(iss, func.tipo_sanguineo, ';');
    getline (iss,func.fatorRH, ';');						
    getline(iss, func.especialidade, ';');  


    return is;
}*/

/*

ostream& operator<< (ostream &os, Funcionario &func) {

	os << "Identificador do funcionário: " << func.id << endl;
	os << "Função: " << func.tipofunc << endl;
	os << "Nome do funcionário: " << func.nome << endl;
	os << "CPF do funcionário: " << func.cpf << endl;
	os << "Idade do funcionário: " << func.idade << endl;
	os << "Tipo Sanguíneo: " << func.tipo_sanguineo << endl;
	os << "Fator RH: " << func.fatorRH << endl;
	os << "Especialidade: " << func.especialidade << endl;
	cout << endl;

	return os;
}

*/
