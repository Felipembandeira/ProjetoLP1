#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include "funcoes.h"
#include "funcionario.h"
//#include "animal.h"
//#include "animalsilvestre.h"

using namespace std;


int main() {

    //map<int, Animal*> animals;
    map<int, vector<Funcionario>> funcionarios;
    map<int, vector<Funcionario>>::iterator itM;
    vector<Funcionario>::iterator itV;


	ifstream funcionarios_arq;
	//ifstream animais_arq;

	funcionarios_arq.open("data/funcionarios.csv");
	//animais_arq.open("data/animais.csv");


	
	if(!funcionarios_arq) {
		cerr << "Os arquivos não foram abertos" << endl;
		exit(1);
	}
/*
		if(!funcionarios_arq || !animais_arq) {
		cerr << "Os arquivos não foram abertos" << endl;
		exit(1);
	}
*/


string linha;

 //Carregando dados dos funcionarios do .csv para programa
//for (int j = 0; j < 4; j++) {
while(getline(funcionarios_arq, linha)){
                

	stringstream aux(linha);
        string id_, funcao, nome, cpf, idade, tipo_sang, fator_rh, especialidade;
        
        getline(aux, id_, ';');
        getline(aux, funcao, ';');
        getline(aux, nome, ';');
        getline(aux, cpf, ';');
        getline(aux, idade,';');
        getline(aux, tipo_sang, ';');
        getline(aux, fator_rh, ';');
        getline(aux, especialidade, ';');           
	
	int id = stoi (id_);

	cout << "id= " << id << endl;
	cout << "funcao= " << funcao << endl;
	cout << "nome= " << funcao << endl;		

	try{

	if (funcao == "Veterinario") {
		Funcionario *func = new Funcionario(id, funcao, nome, cpf, stoi(idade), tipo_sang, fator_rh[0], especialidade);
		funcionarios[id].push_back(*func);
		//func = new Veterinario;
		//funcionarios_arq >> (*func);
        //funcionarios.insert(pair<int,Funcionario*>(chave, func));


//funcionarios.insert(make_pair<int, Funcionario*>(stoi(id), func<Veterinario>>(funcao, nome, cpf, stoi(idade), tipo_sang, fator_rh[0], especialidade)));

//funcionarios[id]= (funcao, nome, cpf, stoi(idade), tipo_sang, fator_rh[0], especialidade);

cout << "entrou1" << endl;

	}

	else if (funcao == "Tratador") {
		Funcionario *func = new Funcionario(id, funcao, nome, cpf, stoi(idade), tipo_sang, fator_rh[0], especialidade);
		funcionarios[id].push_back(*func);
		//func = new Tratador;
		//funcionarios_arq >> (*func);
		//funcionarios.insert(pair<int,Funcionario*>(chave, func));


	//funcionarios.insert(make_pair<int, Funcionario*>(stoi(id), func<Tratador>>(funcao, nome, cpf, stoi(idade), tipo_sang, fator_rh[0], especialidade)));
		cout << "entrou2" << endl;
	}


	else {
		cerr << "Função Inexistente" << endl;
	}

	}   catch(ErroNaSaida &ex){

	   	 cerr<< ex.what()<< endl;
	   }


}
 funcionarios_arq.close();

//	for (map<int, Funcionario*>::iterator it= funcionarios.begin(); it != funcionarios.end(); ++it)
//		cout << it->first << "" << it->second << endl;


/*

//Carregando os dados dos animais do .csv para programa
for (int i = 0; i < 4; i++) {
	string classe,linha2;
	int id;

	animais_arq >> id;
	animais_arq.ignore();
	getline(animais_arq, classe, ';');
	getline(animais_arq, linha2);

		cout << "id ANIMAL= " << id << endl;
	cout << "classe= " << classe << endl;	
	cout << "linha2= " << linha2 << endl;	

	CadastroAnimal( animals,  classe,  animais_arq,  i, id);


	}
		
	cout << "Os dados dos funcionarios e animais foram inseridos no Petfera com sucesso" << endl;


			
	animais_arq.close();

*/
/*
	cout << "Defina qual o id do funcionário que se busca: ";
	int id_ =1;
	map<int, vector<Funcionario>>::iterator itM = funcionarios.find(id);
	*/

for (itM = funcionarios.begin(); itM != funcionarios.end(); itM++){
	

 	itV=funcionarios[(*itM).first].begin();


 	cout << "Identificador do funcionário: " << itV->getId() << endl;
	cout << "Função: " << itV->getTipoFunc() << endl;
	cout << "Nome do funcionário: " << itV->getNome() << endl;
	cout << "CPF do funcionário: " << itV->getCpf() << endl;
	cout << "Idade do funcionário: " << itV->getIdade()<< endl;
	cout << "Tipo Sanguíneo: " << itV->getTipo_Sanguineo() << endl;
	cout << "Fator RH: " << itV->getFatorRH() << endl;
	cout << "Especialidade: " << itV->getEspecialidade() << endl;
	cout << endl;
}




/*
for (itM = funcionarios.begin(); itM != funcionarios.end(); itM++){

	if(funcionarios[itM] == id){

itV =funcionarios[(*itM).first].begin()



	cout << "Identificador do funcionário: " << itV->getId() << endl;
	cout << "Função: " << itV->getTipoFunc() << endl;
	cout << "Nome do funcionário: " << itV->getNome() << endl;
	cout << "CPF do funcionário: " << itV->getCpf() << endl;
	cout << "Idade do funcionário: " << itV->Idade()<< endl;
	cout << "Tipo Sanguíneo: " << itV->getTipo_Sanguineo() << endl;
	cout << "Fator RH: " << itV->getFatorRH() << endl;
	cout << "Especialidade: " << itV->getEspecialidade() << endl;
	cout << endl;



		}
}


*/


		cout << "<<PET FERA>>" << endl;

		while(1) {
			try{
		 		string op1;
		 		int escolha;
		 		int op2;

				
				cout <<	"	Digite 1 para consultar funcionarios cadastrados" << endl;
				cout << "	Digite 2 para consultar animais cadastrados  " << endl;
				cout << "	Digite 3 para remover animais cadastrados no Petfera " << endl;
				cout << "	Digite 4 para remover funcionários cadastrados no Petfera " << endl;
				cout << "	Digite 5 para sair do PetFera" << endl;

				cout << "Digite aqui sua opção:\n";
				cin >> op1;
				ChecarEntrada(op1);
				escolha = stoi(op1);



		 		//Funcionários
		 		switch(escolha){


		 			case 1:
		 				//ConsultaFuncionario(funcionarios);

		 				break;

		 			case 2:
		 				ConsultaAnimal(animals);

		 				break;

		 			case 3:
		 			

		 				cout << "Defina qual o id do animal que será removido: ";
			         	cin >> op2;	
		 				RemoveAnimal(animals, op2);

		 				break;

		 			case 4:
		 		

		 				cout << "Defina qual o id do funcionario que será removido: ";
			        	cin >> op2;	

		 				RemoveFuncionario(funcionarios, op2);
		 				break;

		 			case 5:

		 				exit(1);

		 			default:

		 			cout << "Operador Invalido \n";

	 			}
	 		} catch (EntradaInvalida &ex) {
				cerr << ex.what() << endl;
			}
	 	}
	}

	 		
	 		/*

	Funcionario *func;
	string linha;

while(getline(funcionarios_arq, linha))
{
    stringstream aux(linha);
    string id, funcao, nome, cpf, idade, tipo_sang, fator_rh, especialidade;
    int chave;
    
    getline(aux, id, ';');
    getline(aux, funcao, ';');
    getline(aux, nome, ';');
    getline(aux, cpf, ';');
    getline(aux, idade,';');
    getline(aux, tipo_sang, ';');
    getline(aux, fator_rh, ';');
    getline(aux, especialidade, ';');

    chave = stoi (id);
    
    if(funcao.compare("Veterinario") == 0)
    {
    	func = new Veterinario;
    	funcionarios_arq >> (*func);
        funcionarios.insert(pair<int,Funcionario*>(chave, func));
    }
    else
    {
    	func = new Tratador;
    	funcionarios_arq >> (*func);
        funcionarios.insert(pair<int,Funcionario*>(chave, func));
    }


}
/*
	getline(funcionarios_arq, linha);
	istringstream iss(linha);
	iss >> id;	
	iss.ignore();
	getline(iss, escolha_funcionario, ';');
*/